-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 06, 2021 at 03:33 PM
-- Server version: 8.0.26
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fosdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `catalog_data`
--

CREATE TABLE `catalog_data` (
  `cd_id` int NOT NULL,
  `cd_ud_id` int DEFAULT NULL,
  `cd_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `cd_price` double DEFAULT NULL,
  `cd_desc` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `cd_img` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `cd_log` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `catalog_data`
--

INSERT INTO `catalog_data` (`cd_id`, `cd_ud_id`, `cd_name`, `cd_price`, `cd_desc`, `cd_img`, `cd_log`) VALUES
(4, 2, 'nasi goreng pattaya', 12.9, 'nasi goreng dari jawa tengah', 'nasi-goreng-pattaya.jpg', '2020/12/26 22:31pm'),
(6, 4, 'kuey tiew basah kungfu', 8.5, 'kuey tiew tiau kungfu hustle dari japang', NULL, '2020/12/26 22:46pm'),
(11, 2, 'Nasi Goreng Cina', 6.5, 'Nasi goreng cina from timur tengah.', 'nasi-goreng-cina-800x80011.jpg', '06:35:33 2021-07-19'),
(13, 18, 'New Menu', NULL, 'Waiting for vendor to update the catalog information.', NULL, '05:02:44 2021-09-21');

-- --------------------------------------------------------

--
-- Table structure for table `order_data`
--

CREATE TABLE `order_data` (
  `od_id` int NOT NULL,
  `od_ud_id` int DEFAULT NULL,
  `od_cd_id` int DEFAULT NULL,
  `od_quantity` int DEFAULT NULL,
  `od_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `od_log` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_data`
--

INSERT INTO `order_data` (`od_id`, `od_ud_id`, `od_cd_id`, `od_quantity`, `od_status`, `od_log`) VALUES
(10, 1, 6, 1, 'Completed', NULL),
(23, 17, 6, 1, 'Completed', '00:33:51 2021-07-19'),
(25, 17, 11, 4, 'Completed', '06:35:38 2021-07-19'),
(26, 17, 6, 1, 'Preparing', '00:34:39 2021-07-19'),
(31, 1, 4, 1, 'Preparing', '12:08:20 2021-11-06'),
(32, 1, 6, 1, 'Preparing', '12:08:20 2021-11-06');

-- --------------------------------------------------------

--
-- Table structure for table `payment_data`
--

CREATE TABLE `payment_data` (
  `pd_id` int NOT NULL,
  `pd_od_id` int DEFAULT NULL,
  `pd_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pd_amount` double DEFAULT NULL,
  `pd_type` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pd_log` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_data`
--

INSERT INTO `payment_data` (`pd_id`, `pd_od_id`, `pd_status`, `pd_amount`, `pd_type`, `pd_log`) VALUES
(13, 25, 'Paid', 19.9, 'Cash', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `table_data`
--

CREATE TABLE `table_data` (
  `td_id` int NOT NULL,
  `td_ud_id` int DEFAULT NULL,
  `td_name` int DEFAULT NULL,
  `td_status` int DEFAULT NULL,
  `td_log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `table_data`
--

INSERT INTO `table_data` (`td_id`, `td_ud_id`, `td_name`, `td_status`, `td_log`) VALUES
(1, NULL, 1, 1, NULL),
(2, 1, 2, 0, '12:08:52 2021-11-06'),
(3, NULL, 3, 1, NULL),
(4, NULL, 4, 1, NULL),
(5, NULL, 5, 1, NULL),
(6, NULL, 6, 1, NULL),
(7, NULL, 7, 1, NULL),
(9, NULL, 10, NULL, '14:17:15 2021-11-06');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `ud_id` int NOT NULL,
  `ud_full_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `ud_contact` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `ud_username` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `ud_password` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `ud_role` int DEFAULT NULL,
  `ud_status` int DEFAULT NULL,
  `ud_log` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`ud_id`, `ud_full_name`, `ud_contact`, `ud_username`, `ud_password`, `ud_role`, `ud_status`, `ud_log`) VALUES
(1, 'adam mikaila', '01088842812', 'adam', '1d7c2923c1684726dc23d2901c4d8157', 0, 1, '2021-11-06 12:08:16'),
(2, 'makcik kiah', '0197896765', 'kiah', '0b79eec866e9be97a8fc9fe9955853fd', 1, 1, '2021-11-06 12:41:11'),
(4, 'damm', '098271662', 'damm', '0cb0241e3244dd88a346f9d853d8836a', 1, 1, '2021-09-21 21:39:04'),
(15, 'admin', NULL, 'admin', '21232f297a57a5a743894a0e4a801fc3', 2, 1, '15:28:06 2021-11-06 '),
(16, 'adam aiman', '0108884287', 'adamny', 'c05771e61ad36d14eeb66cb6d00c2ebc', 0, 1, '2021-07-18 03:20:09'),
(17, 'adam aiman zulkornain', '010888287', 'adaman', 'c05771e61ad36d14eeb66cb6d00c2ebc', 0, 1, '2021-09-21 21:40:13'),
(18, 'mazliana', '0142183198', 'mazliana', '8aef2e33be625f1603f1658061866516', 1, 1, '2021-09-21 05:02:25'),
(22, 'adamm', '01099942821', 'adamn', '6f1a9516e45d34c9eac048a37c7a78b2', 0, 1, '2021-09-21 05:03:57'),
(28, 'test', '100', 'test', '098f6bcd4621d373cade4e832627b4f6', 1, 1, '2021-11-06 13:34:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `catalog_data`
--
ALTER TABLE `catalog_data`
  ADD PRIMARY KEY (`cd_id`),
  ADD KEY `ctlog_usrdt_id` (`cd_ud_id`);

--
-- Indexes for table `order_data`
--
ALTER TABLE `order_data`
  ADD PRIMARY KEY (`od_id`),
  ADD KEY `ordr_usrdt_id` (`od_ud_id`),
  ADD KEY `ordr_ctlog_id` (`od_cd_id`);

--
-- Indexes for table `payment_data`
--
ALTER TABLE `payment_data`
  ADD PRIMARY KEY (`pd_id`),
  ADD KEY `inv_ordr_id` (`pd_od_id`);

--
-- Indexes for table `table_data`
--
ALTER TABLE `table_data`
  ADD PRIMARY KEY (`td_id`),
  ADD KEY `td_ud_id` (`td_ud_id`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`ud_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `catalog_data`
--
ALTER TABLE `catalog_data`
  MODIFY `cd_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `order_data`
--
ALTER TABLE `order_data`
  MODIFY `od_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `payment_data`
--
ALTER TABLE `payment_data`
  MODIFY `pd_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `table_data`
--
ALTER TABLE `table_data`
  MODIFY `td_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `ud_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `catalog_data`
--
ALTER TABLE `catalog_data`
  ADD CONSTRAINT `catalog_data_ibfk_1` FOREIGN KEY (`cd_ud_id`) REFERENCES `user_data` (`ud_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_data`
--
ALTER TABLE `order_data`
  ADD CONSTRAINT `order_data_ibfk_1` FOREIGN KEY (`od_cd_id`) REFERENCES `catalog_data` (`cd_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_data_ibfk_2` FOREIGN KEY (`od_ud_id`) REFERENCES `user_data` (`ud_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment_data`
--
ALTER TABLE `payment_data`
  ADD CONSTRAINT `payment_data_ibfk_1` FOREIGN KEY (`pd_od_id`) REFERENCES `order_data` (`od_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `table_data`
--
ALTER TABLE `table_data`
  ADD CONSTRAINT `table_data_ibfk_1` FOREIGN KEY (`td_ud_id`) REFERENCES `user_data` (`ud_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
